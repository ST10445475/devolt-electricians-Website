<?php
$page_title = "Devolt Electricians | Power Simplified";
$current_page = "home";
include 'includes/header.php';
?>

<!-- HERO SECTION -->

<section class="hero" id="home">
  <div class="hero__bg-grid"></div>
  <div class="hero__glow"></div>
  <div class="container hero__content">
    <div class="hero__badge">⚡ Serving Pretoria & Surrounding Areas</div>
    <h1 class="hero__title">
      Power<br>
      <span class="hero__title--accent">Simplified.</span>
    </h1>
    <p class="hero__sub">Professional electrical services for homes and businesses. Fault finding, installations, DB board upgrades, and backup power solutions — done right, every time.</p>
    <div class="hero__ctas">
      <a href="quote.php" class="btn btn--primary">Request a Quote</a>
      <a href="services.php" class="btn btn--ghost">Our Services</a>
    </div>
    <div class="hero__stats">
      <div class="stat">
        <span class="stat__num">2023</span>
        <span class="stat__label">Est.</span>
      </div>
      <div class="stat__divider"></div>
      <div class="stat">
        <span class="stat__num">100%</span>
        <span class="stat__label">Registered</span>
      </div>
      <div class="stat__divider"></div>
      <div class="stat">
        <span class="stat__num">Res &amp; Com</span>
        <span class="stat__label">Clients</span>
      </div>
    </div>
  </div>
  <div class="hero__scroll-hint">
    <span>Scroll</span>
    <div class="hero__scroll-line"></div>
  </div>
</section>

<!-- WHY DEVOLT -->

<section class="why section" id="why">
  <div class="container">
    <div class="section__label">Why Choose Us</div>
    <h2 class="section__title">Reliable Power, <br><span class="accent">Every Time</span></h2>
    <div class="why__grid">
      <div class="why__card">
        <div class="why__icon">🔍</div>
        <h3>Expert Diagnostics</h3>
        <p>Precision fault finding that gets to the root cause — not just a temporary fix.</p>
      </div>
      <div class="why__card">
        <div class="why__icon">🏠</div>
        <h3>Residential &amp; Commercial</h3>
        <p>From homes to offices and small businesses — we handle it all with equal care.</p>
      </div>
      <div class="why__card">
        <div class="why__icon">⚡</div>
        <h3>Fast Response</h3>
        <p>We understand that electrical issues can't wait. We show up and get the job done.</p>
      </div>
      <div class="why__card">
        <div class="why__icon">📋</div>
        <h3>Registered &amp; Trusted</h3>
        <p>Officially registered since 2025, operating professionally since 2023.</p>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES PREVIEW -->

<section class="services-preview section" id="services-preview">
  <div class="container">
    <div class="section__label">What We Do</div>
    <h2 class="section__title">Our <span class="accent">Services</span></h2>
    <div class="services__grid">
      <?php
      $services = [
        ["icon" => "🔧", "title" => "Fault Finding & Repairs", "desc" => "Identifying and fixing electrical faults safely and efficiently."],
        ["icon" => "💡", "title" => "Installations", "desc" => "New electrical installations for residential and commercial properties."],
        ["icon" => "🗃️", "title" => "DB Board Upgrades", "desc" => "Safe, compliant distribution board upgrades and replacements."],
        ["icon" => "🔋", "title" => "Backup Power Solutions", "desc" => "Generators, inverters, and backup systems to keep you powered."],
      ];

      foreach ($services as $s): 
      ?>
        <div class="service-card">
          <div class="service-card__icon"><?= $s['icon'] ?></div>
          <h3 class="service-card__title"><?= $s['title'] ?></h3>
          <p class="service-card__desc"><?= $s['desc'] ?></p>
          <a href="services.php" class="service-card__link">Learn more →</a>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="services__cta">
      <a href="services.php" class="btn btn--primary">View All Services</a>
    </div>
  </div>
</section>

<!-- PROJECTS GALLERY -->

<section class="section projects-section" id="projects">
  <div class="container">
    <div class="section__label">Our Work</div>
    <h2 class="section__title">Completed <span class="accent">Projects</span></h2>

    <div class="projects__grid">
      <div class="project-card">
        <img src="assets/img/image1.jpeg" alt="Electrical wiring installation" loading="lazy" />
        <div class="project-card__overlay"><span>Wiring Installation</span></div>
      </div>

      <div class="project-card">
        <img src="assets/img/image2.jpeg" alt="Transformer box installation" loading="lazy" />
        <div class="project-card__overlay"><span>Transformer Installation</span></div>
      </div>

      <div class="project-card">
        <img src="assets/img/image3.jpeg" alt="DB board breaker installation" loading="lazy" />
        <div class="project-card__overlay"><span>DB Board Build</span></div>
      </div>

      <div class="project-card">
        <img src="assets/img/image4.jpeg" alt="Distribution board wiring" loading="lazy" />
        <div class="project-card__overlay"><span>Distribution Board</span></div>
      </div>
    </div>
  </div>
</section>

<!-- CTA BANNER -->

<section class="cta-banner">
  <div class="cta-banner__glow"></div>
  <div class="container cta-banner__inner">
    <div>
      <h2>Ready to get started?</h2>
      <p>Contact us today or request a free quote. We serve Heidelberg, Pretoria and surrounding areas.</p>
    </div>

    <div class="cta-banner__actions">
      <a href="quote.php" class="btn btn--primary">Get a Quote</a>
      <a href="contact.php" class="btn btn--ghost">Contact Us</a>
      <a href="booking.php" class="nav__link">Book</a>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>