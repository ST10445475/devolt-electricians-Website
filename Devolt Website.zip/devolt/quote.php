<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db_connect.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name         = trim($_POST['name'] ?? '');
    $phone        = trim($_POST['phone'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $client_type  = trim($_POST['client_type'] ?? '');
    $service      = trim($_POST['service'] ?? '');
    $location     = trim($_POST['location'] ?? '');
    $details      = trim($_POST['details'] ?? '');
    $client_email = $_SESSION["user"] ?? ($email !== "" ? $email : null);
    $job_image    = "";

    if (empty($name) || empty($phone) || empty($service) || empty($location)) {
        $error = 'Please fill in all required fields.';
    } else {

        // Accept only real image files up to 5 MB and generate a safe filename.
        if (isset($_FILES["job_image"]) && $_FILES["job_image"]["error"] !== UPLOAD_ERR_NO_FILE) {
            $upload = $_FILES["job_image"];
            $allowed_types = [
                "image/jpeg" => "jpg",
                "image/png" => "png",
                "image/webp" => "webp",
                "image/gif" => "gif"
            ];

            if ($upload["error"] !== UPLOAD_ERR_OK) {
                $error = "The image could not be uploaded. Please try again.";
            } elseif ($upload["size"] > 5 * 1024 * 1024) {
                $error = "Please upload an image smaller than 5 MB.";
            } else {
                $image_info = @getimagesize($upload["tmp_name"]);
                $mime_type = $image_info["mime"] ?? "";

                if (!$image_info || !isset($allowed_types[$mime_type])) {
                    $error = "Please upload a valid JPG, PNG, WEBP, or GIF image.";
                } else {
                    $target_dir = __DIR__ . "/assets/uploads/";
                    if (!is_dir($target_dir) && !mkdir($target_dir, 0755, true)) {
                        $error = "Image storage is unavailable. Please submit without an image.";
                    } else {
                        $file_name = bin2hex(random_bytes(16)) . "." . $allowed_types[$mime_type];
                        if (move_uploaded_file($upload["tmp_name"], $target_dir . $file_name)) {
                            $job_image = "assets/uploads/" . $file_name;
                        } else {
                            $error = "The image could not be saved. Please try again.";
                        }
                    }
                }
            }
        }

        // Save only if the optional image upload passed validation.
        if ($error === "") {
        $stmt = $conn->prepare("
            INSERT INTO quote_requests 
            (name, phone, email, client_type, service, location, details, client_email, job_image)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sssssssss",
            $name,
            $phone,
            $email,
            $client_type,
            $service,
            $location,
            $details,
            $client_email,
            $job_image
        );

        if ($stmt->execute()) {

            // Email to business owner
            $to = 'Yourelectricaldr@icloud.com';
            $subject = "New Quote Request from $name";
            $body = "Name: $name\n"
                  . "Phone: $phone\n"
                  . "Email: $email\n"
                  . "Client Type: $client_type\n"
                  . "Service Needed: $service\n"
                  . "Location: $location\n\n"
                  . "Additional Details:\n$details";

            $headers = "From: noreply@devoltelectricians.co.za" . (!empty($email) ? "\r\nReply-To: $email" : "");

            @mail($to, $subject, $body, $headers);

            // Confirmation email to client
            if (!empty($email)) {
                $client_subject = "Quote Request Received - Devolt Electricians";

                $client_body = "Hi $name,\n\n"
                    . "Thank you for requesting a quote from Devolt Electricians.\n"
                    . "We have received your request for: $service.\n\n"
                    . "We will review your details and get back to you shortly.\n\n"
                    . "Kind regards,\n"
                    . "Devolt Electricians";

                $client_headers = "From: noreply@devoltelectricians.co.za";

                @mail($email, $client_subject, $client_body, $client_headers);
            }

            $success = true;

        } else {
            $error = "Could not save quote request.";
        }

        $stmt->close();
        }
    }
}

$page_title = "Request a Quote | Devolt Electricians";
$current_page = "quote";
include 'includes/header.php';
?>

<section class="page-hero">
    <div class="page-hero__glow"></div>
    <div class="container">
        <div class="section__label">Free Quote</div>
        <h1 class="page-hero__title">Request a <span class="accent">Quote</span></h1>
        <p>Fill in the form below and we’ll get back to you as soon as possible.</p>
    </div>
</section>

<section class="section">
    <div class="container quote__wrap">

        <?php if ($success): ?>
            <div class="form-success large">
                ✅ <strong>Quote request received!</strong><br>
                Thank you, <?= htmlspecialchars($name) ?>. We'll review your request and be in touch shortly.
            </div>
        <?php else: ?>

            <?php if ($error): ?>
                <div class="form-error">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <form class="contact-form quote-form" method="POST" action="quote.php" enctype="multipart/form-data">

                <h2>Your <span class="accent">Details</span></h2>

                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Full Name <span class="req">*</span></label>
                        <input type="text"  name="name" placeholder="Your full name" required id="name">
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number <span class="req">*</span></label>
                        <input type="tel"  name="phone" placeholder="e.g. 082 123 4567" required id="phone">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email"  name="email" placeholder="your@email.com" id="email">
                    </div>

                    <div class="form-group">
                        <label for="client_type">Client Type</label>
                        <select  name="client_type" id="client_type">
                            <option value="">-- Select --</option>
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                        </select>
                    </div>
                </div>

                <h2 style="margin-top:2rem;">Service <span class="accent">Required</span></h2>

                <div class="form-row">
                    <div class="form-group">
                        <label for="service">Type of Service <span class="req">*</span></label>
                        <select  name="service" required id="service">
                            <option value="">-- Select a service --</option>
                            <option value="Fault Finding & Repairs">Fault Finding & Repairs</option>
                            <option value="Electrical Installation">Electrical Installation</option>
                            <option value="DB Board Upgrade">DB Board Upgrade</option>
                            <option value="Backup Power Solution">Backup Power Solution</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="location">Your Location / Area <span class="req">*</span></label>
                        <input type="text"  name="location" placeholder="e.g. Centurion, Pretoria East" required id="location">
                    </div>
                </div>

                <div class="form-group">
                    <label for="details">Additional Details</label>
                    <textarea  name="details" rows="5" placeholder="Describe the job..." id="details"></textarea>
                </div>

                <div class="form-group">
                    <label for="job_image">Upload Job Image</label>
                    <input type="file"  name="job_image" accept="image/*" id="job_image">
                </div>

                <button type="submit" class="btn btn--primary btn--full">
                    Submit Quote Request ⚡
                </button>

            </form>

        <?php endif; ?>

    </div>
</section>

<?php include 'includes/footer.php'; ?>