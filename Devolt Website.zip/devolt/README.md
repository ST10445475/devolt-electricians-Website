# Devolt Electricians Website

A responsive PHP website for Devolt Electricians, with service information, quote requests, contact messages, client registration/login, bookings, and a client dashboard. The interface uses HTML, CSS, and JavaScript; PHP and MySQL/MariaDB handle server-side forms and account data.

## Features

- Home, services, about, and contact pages
- Quote requests with optional job-image upload
- Client registration, login, logout, and password-reset flow
- Appointment booking and client dashboard
- Responsive navigation and scroll-reveal effects

## Requirements

- PHP 8.0 or newer with `mysqli` and `fileinfo` enabled
- MySQL or MariaDB
- A local PHP server such as XAMPP, or a PHP-capable hosting provider

## Run locally with XAMPP

1. Install and start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Copy the `devolt` project folder into XAMPP's `htdocs` directory.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`.
4. Create a database named `devolt_db` using `utf8mb4` if possible.
5. Select the database, choose **Import**, and import `database/schema.sql`. This file creates empty tables; it deliberately contains no customer records.
6. Check `db_connect.php`. The included defaults (`localhost`, user `root`, blank password) are typical for a fresh local XAMPP installation only. Change these values to match your local database or hosting provider. Do not commit production credentials.
7. Visit `http://localhost/devolt/` in your browser.

Email sending depends on the PHP/server mail configuration and may not work automatically on a local XAMPP setup. The password-reset link currently uses a localhost URL for local testing; change it to your deployed site URL and configure mail delivery before production use. Test the contact, quote, booking, registration, login, and password-reset flows before presenting the site.

## Project structure

```text
devolt/
├── assets/
│   ├── css/style.css
│   ├── js/main.js
│   ├── img/
│   └── uploads/          # user uploads; files are not committed
├── database/schema.sql
├── includes/
│   ├── header.php
│   └── footer.php
├── about.php
├── booking.php
├── client_dashboard.php
├── contact.php
├── dashboard.php
├── db_connect.php
├── forgot_password.php
├── index.php
├── login.php
├── logout.php
├── quote.php
├── register.php
├── reset_password.php
├── services.php
├── .gitignore
└── README.md
```

## GitHub setup

1. Create a new **empty** GitHub repository (for example, `devolt-electricians`).
2. Extract/copy the project folder contents into your local project folder. Do not add the original ZIP or a database dump containing real customer records.
3. Open a terminal in the project folder and run:

   ```bash
   git init
   git add .
   git status
   git commit -m "Initial Devolt website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

4. Replace the example GitHub URL above with your actual repository URL. Check the repository page to confirm the files are visible.
5. Copy the actual repository URL into this README if your assessor expects the GitHub link to be written here.

Before committing, inspect `git status` and ensure there are no passwords, `.env` files, uploaded customer images, private customer details, or database exports with real records.

## Final testing checklist

- [ ] Every navigation link opens the correct page.
- [ ] The mobile menu opens and closes with keyboard-accessible controls.
- [ ] Layout works on desktop and mobile widths.
- [ ] Images load and have meaningful alternative text.
- [ ] Quote and contact forms validate and save records to the database.
- [ ] Image uploads reject unsupported formats and files over 5 MB.
- [ ] Registration, login, logout, bookings, and dashboard work.
- [ ] Password reset is tested with a configured mail service.
- [ ] No PHP errors or JavaScript errors appear in the browser console.
- [ ] README contains the real GitHub repository URL.
