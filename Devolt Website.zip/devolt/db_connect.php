<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "devolt_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    http_response_code(500);
    exit("The website is temporarily unavailable. Please try again later.");
}
?>