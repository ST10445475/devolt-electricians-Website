<?php
session_start();
include 'db_connect.php';

$message = "";
$error = "";
$token = $_GET["token"] ?? "";

if (empty($token)) {
    $error = "Invalid reset link.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST["token"];
    $new_password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    if ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT email FROM password_resets WHERE token = ? AND expires_at > NOW()");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $email = $row["email"];

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update = $conn->prepare("UPDATE clients SET password = ? WHERE email = ?");
            $update->bind_param("ss", $hashed_password, $email);

            if ($update->execute()) {
                $delete = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
                $delete->bind_param("s", $email);
                $delete->execute();

                $message = "Password updated successfully. You can now login.";
            } else {
                $error = "Could not update password.";
            }
        } else {
            $error = "Reset link is invalid or expired.";
        }
    }
}

$page_title = "Reset Password | Devolt Electricians";
$current_page = "";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Account Help</div>
    <h1 class="page-hero__title">Reset <span class="accent">Password</span></h1>
    <p>Create a new password for your account.</p>
  </div>
</section>

<section class="section">
  <div class="container quote__wrap">

    <?php if ($message): ?>
      <div class="form-success large">
        ✅ <?= $message ?><br><br>
        <a href="login.php">Go to Login</a>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="form-error">⚠️ <?= $error ?></div>
    <?php endif; ?>

    <?php if (!$message && !empty($token)): ?>
      <form class="contact-form" method="POST">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

        <div class="form-group">
          <label for="password">New Password <span class="req">*</span></label>
          <input type="password"  name="password" required id="password">
        </div>

        <div class="form-group">
          <label for="confirm_password">Confirm Password <span class="req">*</span></label>
          <input type="password"  name="confirm_password" required id="confirm_password">
        </div>

        <button type="submit" class="btn btn--primary btn--full">
          Reset Password ⚡
        </button>
      </form>
    <?php endif; ?>

  </div>
</section>

<?php include 'includes/footer.php'; ?>