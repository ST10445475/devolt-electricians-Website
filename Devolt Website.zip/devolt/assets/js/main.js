'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('site-header');
  const burgerButton = document.getElementById('burger-btn');
  const mainNav = document.getElementById('main-nav');

  const updateHeader = () => {
    if (header) header.classList.toggle('scrolled', window.scrollY > 50);
  };

  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  if (burgerButton && mainNav) {
    burgerButton.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      burgerButton.classList.toggle('open', isOpen);
      burgerButton.setAttribute('aria-expanded', String(isOpen));
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    mainNav.querySelectorAll('.nav__link').forEach((link) => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        burgerButton.classList.remove('open');
        burgerButton.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }

  const revealElements = document.querySelectorAll(
    '.why__card, .service-card, .service-full-card, .highlight-card, .value-card'
  );

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          currentObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    revealElements.forEach((element, index) => {
      element.style.opacity = '0';
      element.style.transform = 'translateY(28px)';
      element.style.transition = `opacity 0.5s ease ${index * 0.07}s, transform 0.5s ease ${index * 0.07}s`;
      observer.observe(element);
    });
  }
});
