// ==========================================
// DEVOLT ELECTRICIANS — MAIN JS
// ==========================================

document.addEventListener(‘DOMContentLoaded’, () => {

// –– STICKY HEADER ––
const header = document.getElementById(‘site-header’);
const onScroll = () => {
header?.classList.toggle(‘scrolled’, window.scrollY > 50);
};
window.addEventListener(‘scroll’, onScroll, { passive: true });

// –– MOBILE NAV ––
const burgerBtn = document.getElementById(‘burger-btn’);
const mainNav   = document.getElementById(‘main-nav’);

burgerBtn?.addEventListener(‘click’, () => {
const open = mainNav.classList.toggle(‘open’);
burgerBtn.classList.toggle(‘open’, open);
document.body.style.overflow = open ? ‘hidden’ : ‘’;
});

// Close nav on link click
mainNav?.querySelectorAll(’.nav__link’).forEach(link => {
link.addEventListener(‘click’, () => {
mainNav.classList.remove(‘open’);
burgerBtn?.classList.remove(‘open’);
document.body.style.overflow = ‘’;
});
});

// –– SCROLL REVEAL ––
const revealEls = document.querySelectorAll(
‘.why__card, .service-card, .service-full-card, .highlight-card, .value-card’
);

if (‘IntersectionObserver’ in window) {
const observer = new IntersectionObserver((entries) => {
entries.forEach(entry => {
if (entry.isIntersecting) {
entry.target.style.opacity = ‘1’;
entry.target.style.transform = ‘translateY(0)’;
observer.unobserve(entry.target);
}
});
}, { threshold: 0.12 });

```
revealEls.forEach((el, i) => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(28px)';
  el.style.transition = `opacity 0.5s ease ${i * 0.07}s, transform 0.5s ease ${i * 0.07}s`;
  observer.observe(el);
});
```

}

});