<?php
$page_title = "Services | Devolt Electricians";
$current_page = "services";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">What We Offer</div>
    <h1 class="page-hero__title">Our <span class="accent">Services</span></h1>
    <p>Professional electrical solutions for homes and businesses across Pretoria and surrounding areas.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="services__full-grid">

  <div class="service-full-card">
    <div class="service-full-card__icon">🔍</div>
    <div class="service-full-card__body">
      <h2>Fault Finding &amp; Repairs</h2>
      <p>Electrical faults can be dangerous and disruptive. Our team uses professional diagnostic methods to identify the exact source of the problem — whether it's a tripping breaker, dead outlet, or intermittent fault — and repairs it safely and efficiently.</p>
      <ul>
        <li>Circuit tracing and diagnostics</li>
        <li>Tripping breaker investigation</li>
        <li>Short circuit location and repair</li>
        <li>Wiring fault identification</li>
      </ul>
    </div>
  </div>

  <div class="service-full-card">
    <div class="service-full-card__icon">💡</div>
    <div class="service-full-card__body">
      <h2>Electrical Installations</h2>
      <p>From new builds to renovations, we handle all electrical installations with precision and compliance. We ensure every installation meets South African electrical standards and is safe for long-term use.</p>
      <ul>
        <li>Residential wiring and rewiring</li>
        <li>Light fittings and ceiling fans</li>
        <li>Plug points and switches</li>
        <li>Commercial electrical fit-outs</li>
      </ul>
    </div>
  </div>

  <div class="service-full-card">
    <div class="service-full-card__icon">🗃️</div>
    <div class="service-full-card__body">
      <h2>DB Board Upgrades</h2>
      <p>An outdated or overloaded distribution board is a fire hazard. We perform professional DB board upgrades and replacements, ensuring your electrical system is safe, compliant, and ready for modern power demands.</p>
      <ul>
        <li>Old fuse board replacement</li>
        <li>Circuit breaker upgrades</li>
        <li>Earth leakage protection installation</li>
        <li>Compliance certificates available</li>
      </ul>
    </div>
  </div>

  <div class="service-full-card">
    <div class="service-full-card__icon">🔋</div>
    <div class="service-full-card__body">
      <h2>Backup Power Solutions</h2>
      <p>Load shedding and power outages don't have to disrupt your home or business. We supply and install a range of backup power solutions tailored to your needs and budget.</p>
      <ul>
        <li>Inverter installation and setup</li>
        <li>Generator connections and transfer switches</li>
        <li>Battery backup systems</li>
        <li>Solar-ready DB configurations</li>
      </ul>
    </div>
  </div>

</div>

  </div>
</section>

<section class="cta-banner">
  <div class="cta-banner__glow"></div>
  <div class="container cta-banner__inner">
    <div>
      <h2>Need any of these services?</h2>
      <p>Get in touch today or request a free quote. We'll get back to you promptly.</p>
    </div>
    <div class="cta-banner__actions">
      <a href="quote.php" class="btn btn--primary">Request a Quote</a>
      <a href="contact.php" class="btn btn--ghost">Contact Us</a>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>