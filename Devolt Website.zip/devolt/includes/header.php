<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : 'Devolt Electricians'; ?></title>
  <meta name="description" content="Devolt Electricians — Professional electrical services in Pretoria and surrounding areas. Fault finding, DB board upgrades, installations, and backup power solutions." />

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;900&family=Barlow:wght@300;400;500&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>

<header class="site-header" id="site-header">
  <div class="container header__inner">

    <a href="index.php" class="header__logo">
      <img src="assets/img/logo.jpeg" alt="Devolt Electricians Logo" />
    </a>

    <nav class="header__nav" id="main-nav" aria-label="Main navigation">

      <a href="index.php" class="nav__link <?= ($current_page === 'home') ? 'active' : '' ?>">Home</a>

      <a href="services.php" class="nav__link <?= ($current_page === 'services') ? 'active' : '' ?>">Services</a>

      <a href="about.php" class="nav__link <?= ($current_page === 'about') ? 'active' : '' ?>">About</a>

      <a href="contact.php" class="nav__link <?= ($current_page === 'contact') ? 'active' : '' ?>">Contact</a>

      <?php if (isset($_SESSION["user"])): ?>
        <a href="client_dashboard.php" class="nav__link">Dashboard</a>
        <a href="logout.php" class="nav__link">Logout</a>
      <?php else: ?>
        <a href="login.php" class="nav__link">Login</a>
        <a href="register.php" class="nav__link">Register</a>
      <?php endif; ?>

      <a href="quote.php" class="btn btn--primary btn--sm">Get a Quote</a>

    </nav>

    <button type="button" class="header__burger" id="burger-btn" aria-label="Toggle menu" aria-controls="main-nav" aria-expanded="false">
      <span></span>
      <span></span>
      <span></span>
    </button>

  </div>
</header>