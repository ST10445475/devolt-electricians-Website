<footer class="site-footer">
  <div class="footer__glow"></div>
  <div class="container footer__inner">
    <div class="footer__brand">
      <img src="assets/img/logo.jpeg" alt="Devolt Electricians" class="footer__logo" />
      <p>Professional electrical services for residential and commercial clients across Pretoria and surrounding areas.</p>
      <div class="footer__socials">
        <a href="https://wa.me/27655335257" target="_blank" rel="noopener noreferrer" aria-label="Contact Devolt on WhatsApp">
          <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        </a>
        <a href="https://www.google.com/maps/search/Devolt+Electricians" target="_blank" rel="noopener" aria-label="Google Business">
          <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
        </a>
      </div>
    </div>
    <div class="footer__links">
      <h4>Quick Links</h4>
      <a href="index.php">Home</a>
      <a href="services.php">Services</a>
      <a href="about.php">About</a>
      <a href="contact.php">Contact</a>
      <a href="quote.php">Get a Quote</a>
    </div>
    <div class="footer__services">
      <h4>Services</h4>
      <span>Fault Finding &amp; Repairs</span>
      <span>Electrical Installations</span>
      <span>DB Board Upgrades</span>
      <span>Backup Power Solutions</span>
      <span>Residential &amp; Commercial</span>
    </div>
    <div class="footer__contact">
      <h4>Contact</h4>
      <p>📍 Heidelberg | Pretoria &amp; Surrounds</p>
      <p>📱 <a href="https://wa.me/27655335257" target="_blank" rel="noopener noreferrer">065 533 5257</a></p>
      <p>🔍 <a href="https://www.google.com/maps/search/Devolt+Electricians" target="_blank" rel="noopener noreferrer">Find us on Google</a></p>
    </div>
  </div>
  <div class="footer__bottom">
    <div class="container">
      <p>&copy; <?= date('Y') ?> Devolt Electricians. All rights reserved.</p>
      <p>Registered company · Power Simplified</p>
    </div>
  </div>
</footer>

<script src="assets/js/main.js"></script>

</body>
</html>