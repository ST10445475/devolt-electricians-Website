<?php
session_start();
include 'db_connect.php';

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if (empty($name) || empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $check = $conn->prepare("SELECT id FROM clients WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "This email is already registered. Please login.";
        } else {
            $stmt = $conn->prepare("INSERT INTO clients (full_name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashed_password);

            if ($stmt->execute()) {
                $message = "Registration successful. You can now login.";
            } else {
                $error = "Something went wrong. Please try again.";
            }

            $stmt->close();
        }

        $check->close();
    }
}

$page_title = "Register | Devolt Electricians";
$current_page = "";
include 'includes/header.php';
?>

<section class="page-hero">
    <div class="page-hero__glow"></div>
    <div class="container">
        <div class="section__label">Client Access</div>
        <h1 class="page-hero__title">
            Create <span class="accent">Account</span>
        </h1>
        <p>Register to request services and quotes faster.</p>
    </div>
</section>

<section class="section">
    <div class="container quote__wrap">

        <?php if ($message): ?>
            <div class="form-success large">
                ✅ <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="form-error">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form class="contact-form" method="POST">

            <h2>Your <span class="accent">Details</span></h2>

            <div class="form-group">
                <label for="name">Full Name <span class="req">*</span></label>
                <input type="text"  name="name" placeholder="Enter your full name" required id="name">
            </div>

            <div class="form-group">
                <label for="email">Email Address <span class="req">*</span></label>
                <input type="email"  name="email" placeholder="Enter your email" required id="email">
            </div>

            <div class="form-group">
                <label for="password">Password <span class="req">*</span></label>
                <input type="password"  name="password" placeholder="Create a password" required id="password">
            </div>

            <button type="submit" class="btn btn--primary btn--full">
                Register ⚡
            </button>

        </form>

        <br>

        <p>
            Already have an account?
            <a href="login.php">Login here</a>
        </p>

    </div>
</section>

<?php include 'includes/footer.php'; ?>