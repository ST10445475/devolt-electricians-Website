<?php
session_start();
include 'db_connect.php';

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);

    if (empty($email)) {
        $error = "Please enter your email address.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM clients WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $token = bin2hex(random_bytes(32));
            $expires_at = date("Y-m-d H:i:s", strtotime("+1 hour"));

            $insert = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
            $insert->bind_param("sss", $email, $token, $expires_at);
            $insert->execute();

            $reset_link = "http://localhost/devolt/reset_password.php?token=" . $token;

            $subject = "Password Reset - Devolt Electricians";
            $body = "Hi,\n\nClick the link below to reset your password:\n\n$reset_link\n\nThis link expires in 1 hour.";
            $headers = "From: noreply@devoltelectricians.co.za";

            mail($email, $subject, $body, $headers);

            $message = "Password reset link created. Check your email.";
            $message .= "<br><br><strong>For XAMPP testing, use this link:</strong><br>";
            $message .= "<a href='$reset_link'>$reset_link</a>";
        } else {
            $error = "No account found with that email.";
        }

        $stmt->close();
    }
}

$page_title = "Forgot Password | Devolt Electricians";
$current_page = "";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Account Help</div>
    <h1 class="page-hero__title">Forgot <span class="accent">Password</span></h1>
    <p>Enter your email address to reset your password.</p>
  </div>
</section>

<section class="section">
  <div class="container quote__wrap">

    <?php if ($message): ?>
      <div class="form-success large"><?= $message ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="form-error">⚠️ <?= $error ?></div>
    <?php endif; ?>

    <form class="contact-form" method="POST">
      <div class="form-group">
        <label for="email">Email Address <span class="req">*</span></label>
        <input type="email"  name="email" required id="email">
      </div>

      <button type="submit" class="btn btn--primary btn--full">
        Send Reset Link ⚡
      </button>
    </form>

    <br>
    <a href="login.php">Back to Login</a>

  </div>
</section>

<?php include 'includes/footer.php'; ?>