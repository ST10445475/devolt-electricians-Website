<?php
$page_title = "About | Devolt Electricians";
$current_page = "about";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Who We Are</div>
    <h1 class="page-hero__title">About <span class="accent">Devolt</span></h1>
    <p>A team of dedicated electricians committed to safe, professional, and reliable service.</p>
  </div>
</section>

<section class="section about-section">
  <div class="container about__grid">
    <div class="about__text">
      <div class="section__label">Our Story</div>
      <h2>Power Simplified, <span class="accent">Since 2023</span></h2>
      <p>Devolt Electricians was founded in 2023 by an electrician with a passion for delivering quality electrical work to residential and commercial clients. What started as hands-on trade experience quickly grew into a registered company, officially incorporated in 2025.</p>
      <p>Based in Heidelberg and operating across Pretoria and surrounding areas, we've built our reputation on showing up, doing the job right, and making sure every client feels confident in the safety and reliability of their electrical systems.</p>
      <p>Whether you're a homeowner dealing with a fault, a small business needing an upgrade, or an office requiring a full electrical fit-out — Devolt is equipped to handle it with the same level of care and professionalism.</p>
    </div>
    <div class="about__highlights">
      <div class="highlight-card">
        <span class="highlight-card__icon">📅</span>
        <div>
          <strong>Operating Since 2023</strong>
          <p>Years of hands-on experience in the electrical trade.</p>
        </div>
      </div>
      <div class="highlight-card">
        <span class="highlight-card__icon">🏢</span>
        <div>
          <strong>Officially Registered (2025)</strong>
          <p>A fully registered company operating with accountability.</p>
        </div>
      </div>
      <div class="highlight-card">
        <span class="highlight-card__icon">👥</span>
        <div>
          <strong>Team-Based Operations</strong>
          <p>We work as a team to deliver efficient, high-quality results.</p>
        </div>
      </div>
      <div class="highlight-card">
        <span class="highlight-card__icon">📍</span>
        <div>
          <strong>Heidelberg-Based</strong>
          <p>Proudly serving Pretoria and surrounding areas.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section values-section">
  <div class="container">
    <div class="section__label">What Drives Us</div>
    <h2 class="section__title">Our <span class="accent">Values</span></h2>
    <div class="values__grid">
      <div class="value-card">
        <div class="value-card__num">01</div>
        <h3>Safety First</h3>
        <p>Every job is done to the highest safety standards. Electrical work done wrong is dangerous — we don't cut corners.</p>
      </div>
      <div class="value-card">
        <div class="value-card__num">02</div>
        <h3>Reliability</h3>
        <p>We show up when we say we will, and we follow through on every commitment made to our clients.</p>
      </div>
      <div class="value-card">
        <div class="value-card__num">03</div>
        <h3>Transparency</h3>
        <p>No hidden costs. No surprises. We communicate clearly about what needs to be done and why.</p>
      </div>
      <div class="value-card">
        <div class="value-card__num">04</div>
        <h3>Growth</h3>
        <p>We're constantly improving — both our skills and our service — to be the best electrical partner for our clients.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>