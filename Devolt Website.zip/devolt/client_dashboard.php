<?php
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

$client_email = $_SESSION["user"];

$page_title = "Client Dashboard | Devolt Electricians";
$current_page = "";
include 'includes/header.php';

$quotes = $conn->prepare("SELECT * FROM quote_requests WHERE email = ? OR client_email = ? ORDER BY created_at DESC");
$quotes->bind_param("ss", $client_email, $client_email);
$quotes->execute();
$quote_results = $quotes->get_result();

$bookings = $conn->prepare("SELECT * FROM bookings WHERE client_email = ? ORDER BY created_at DESC");
$bookings->bind_param("s", $client_email);
$bookings->execute();
$booking_results = $bookings->get_result();
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Client Portal</div>
    <h1 class="page-hero__title">My <span class="accent">Dashboard</span></h1>
    <p>View your quote requests and bookings.</p>
  </div>
</section>

<section class="section">
  <div class="container">

    <h2 class="section__title">My <span class="accent">Quotes</span></h2>

    <?php if ($quote_results->num_rows > 0): ?>
      <div class="services__full-grid">
        <?php while ($quote = $quote_results->fetch_assoc()): ?>
          <div class="service-full-card">
            <div class="service-full-card__icon">⚡</div>
            <div class="service-full-card__body">
              <h2><?= htmlspecialchars($quote["service"]) ?></h2>
              <p><strong>Status:</strong> <?= htmlspecialchars($quote["status"] ?? "Pending") ?></p>
              <p><strong>Location:</strong> <?= htmlspecialchars($quote["location"]) ?></p>
              <p><strong>Details:</strong> <?= htmlspecialchars($quote["details"] ?? "") ?></p>
              <p><strong>Date:</strong> <?= htmlspecialchars($quote["created_at"]) ?></p>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>You have not submitted any quote requests yet.</p>
    <?php endif; ?>

    <br><br>

    <h2 class="section__title">My <span class="accent">Bookings</span></h2>

    <?php if ($booking_results->num_rows > 0): ?>
      <div class="services__full-grid">
        <?php while ($booking = $booking_results->fetch_assoc()): ?>
          <div class="service-full-card">
            <div class="service-full-card__icon">📅</div>
            <div class="service-full-card__body">
              <h2><?= htmlspecialchars($booking["service"]) ?></h2>
              <p><strong>Status:</strong> <?= htmlspecialchars($booking["status"]) ?></p>
              <p><strong>Date:</strong> <?= htmlspecialchars($booking["booking_date"]) ?></p>
              <p><strong>Time:</strong> <?= htmlspecialchars($booking["booking_time"]) ?></p>
              <p><strong>Address:</strong> <?= htmlspecialchars($booking["address"]) ?></p>
              <p><strong>Notes:</strong> <?= htmlspecialchars($booking["notes"] ?? "") ?></p>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>You have not made any bookings yet.</p>
    <?php endif; ?>

  </div>
</section>

<?php include 'includes/footer.php'; ?>