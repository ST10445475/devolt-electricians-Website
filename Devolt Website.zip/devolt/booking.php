<?php
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

$success = false;
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $client_email = $_SESSION["user"];
    $full_name = trim($_POST["full_name"]);
    $phone = trim($_POST["phone"]);
    $service = trim($_POST["service"]);
    $booking_date = $_POST["booking_date"];
    $booking_time = $_POST["booking_time"];
    $address = trim($_POST["address"]);
    $notes = trim($_POST["notes"]);

    if (empty($full_name) || empty($phone) || empty($service) || empty($booking_date) || empty($booking_time) || empty($address)) {
        $error = "Please fill in all required fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO bookings (client_email, full_name, phone, service, booking_date, booking_time, address, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $client_email, $full_name, $phone, $service, $booking_date, $booking_time, $address, $notes);

        if ($stmt->execute()) {
            $success = true;
        } else {
            $error = "Could not create booking.";
        }

        $stmt->close();
    }
}

$page_title = "Book a Service | Devolt Electricians";
$current_page = "";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Booking</div>
    <h1 class="page-hero__title">Book a <span class="accent">Service</span></h1>
    <p>Choose your service, date, and time.</p>
  </div>
</section>

<section class="section">
  <div class="container quote__wrap">

    <?php if ($success): ?>
      <div class="form-success large">
        ✅ Booking submitted successfully. We will confirm your appointment shortly.
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="form-error">⚠️ <?= $error ?></div>
    <?php endif; ?>

    <form class="contact-form" method="POST">
      <h2>Your <span class="accent">Booking Details</span></h2>

      <div class="form-group">
        <label for="full_name">Full Name <span class="req">*</span></label>
        <input type="text"  name="full_name" required id="full_name">
      </div>

      <div class="form-group">
        <label for="phone">Phone Number <span class="req">*</span></label>
        <input type="tel"  name="phone" required id="phone">
      </div>

      <div class="form-group">
        <label for="service">Service <span class="req">*</span></label>
        <select  name="service" required id="service">
          <option value="">-- Select Service --</option>
          <option value="Fault Finding & Repairs">Fault Finding & Repairs</option>
          <option value="Electrical Installation">Electrical Installation</option>
          <option value="DB Board Upgrade">DB Board Upgrade</option>
          <option value="Backup Power Solution">Backup Power Solution</option>
          <option value="Other">Other</option>
        </select>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="booking_date">Booking Date <span class="req">*</span></label>
          <input type="date"  name="booking_date" required id="booking_date">
        </div>

        <div class="form-group">
          <label for="booking_time">Booking Time <span class="req">*</span></label>
          <input type="time"  name="booking_time" required id="booking_time">
        </div>
      </div>

      <div class="form-group">
        <label for="address">Address <span class="req">*</span></label>
        <input type="text"  name="address" placeholder="Enter job address" required id="address">
      </div>

      <div class="form-group">
        <label for="notes">Additional Notes</label>
        <textarea  name="notes" rows="5" placeholder="Add any extra details..." id="notes"></textarea>
      </div>

      <button type="submit" class="btn btn--primary btn--full">
        Submit Booking ⚡
      </button>
    </form>

  </div>
</section>

<?php include 'includes/footer.php'; ?>