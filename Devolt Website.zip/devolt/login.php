<?php
session_start();
include 'db_connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id, full_name, password FROM clients WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $client = $result->fetch_assoc();

        if (password_verify($password, $client["password"])) {
            $_SESSION["user"] = $email;
            $_SESSION["client_name"] = $client["full_name"];

            header("Location: index.php");
            exit();
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "No account found. Please register first.";
    }

    $stmt->close();
}

$page_title = "Login | Devolt Electricians";
$current_page = "";
include 'includes/header.php';
?>

<section class="page-hero">
    <div class="page-hero__glow"></div>
    <div class="container">
        <div class="section__label">Client Access</div>
        <h1 class="page-hero__title">
            Client <span class="accent">Login</span>
        </h1>
        <p>Login to access your Devolt account and request services faster.</p>
    </div>
</section>

<section class="section">
    <div class="container quote__wrap">

        <?php if ($error): ?>
            <div class="form-error">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form class="contact-form" method="POST">

            <h2>Login to <span class="accent">Your Account</span></h2>

            <div class="form-group">
                <label for="email">Email Address <span class="req">*</span></label>
                <input type="email"  name="email" placeholder="Enter your email" required id="email">
            </div>

            <div class="form-group">
                <label for="password">Password <span class="req">*</span></label>
                <input type="password"  name="password" placeholder="Enter your password" required id="password">
            </div>

            <button type="submit" class="btn btn--primary btn--full">
                Login ⚡
            </button>

        </form>

        <br>

        <p>
            Don’t have an account?
            <a href="register.php">Register here</a>

        
        </p>

        <p>
    Forgot your password?
    <a href="forgot_password.php">Reset it here</a>
</p>

    </div>
</section>

<?php include 'includes/footer.php'; ?>