<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db_connect.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name    = trim($_POST['name'] ?? '');
  $phone   = trim($_POST['phone'] ?? '');
  $email   = trim($_POST['email'] ?? '');
  $message = trim($_POST['message'] ?? '');

  if (empty($name) || empty($phone) || empty($message)) {
    $error = 'Please fill in all required fields.';
  } else {
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, phone, email, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $phone, $email, $message);

    if ($stmt->execute()) {
      $to      = 'Yourelectricaldr@icloud.com';
      $subject = "New Contact Message from $name";
      $body    = "Name: $name\nPhone: $phone\nEmail: $email\n\nMessage:\n$message";
      $headers = "From: noreply@devoltelectricians.co.za" . (!empty($email) ? "\r\nReply-To: $email" : "");

      mail($to, $subject, $body, $headers);
      $success = true;
    } else {
      $error = 'Could not save message.';
    }

    $stmt->close();
  }
}

$page_title = "Contact | Devolt Electricians";
$current_page = "contact";
include 'includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero__glow"></div>
  <div class="container">
    <div class="section__label">Reach Out</div>
    <h1 class="page-hero__title">Get In <span class="accent">Touch</span></h1>
    <p>We're available for quotes, bookings, and general enquiries.</p>
  </div>
</section>

<section class="section contact-section">
  <div class="container contact__grid">

    <div class="contact__info">
      <h2>Contact <span class="accent">Details</span></h2>

      <div class="contact-item">
        <div class="contact-item__icon">📍</div>
        <div>
          <strong>Location</strong>
          <p>Based in Heidelberg — operating in Pretoria and surrounding areas</p>
        </div>
      </div>

      <div class="contact-item">
        <div class="contact-item__icon">📞</div>
        <div>
          <strong>Telephone</strong>
          <p><a href="tel:0727109584">072 710 9584</a></p>
        </div>
      </div>

      <div class="contact-item">
        <div class="contact-item__icon">📱</div>
        <div>
          <strong>WhatsApp</strong>
          <p><a href="https://wa.me/27655335257" target="_blank" rel="noopener noreferrer">065 533 5257</a></p>
        </div>
      </div>

      <div class="contact-item">
        <div class="contact-item__icon">✉️</div>
        <div>
          <strong>Email</strong>
          <p><a href="mailto:Yourelectricaldr@icloud.com">Yourelectricaldr@icloud.com</a></p>
        </div>
      </div>
    </div>

    <div class="contact__form-wrap">
      <h2>Send a <span class="accent">Message</span></h2>

      <?php if ($success): ?>
        <div class="form-success">
          ✅ Your message has been sent! We'll get back to you shortly.
        </div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="form-error">⚠️ <?= $error ?></div>
      <?php endif; ?>

      <form class="contact-form" method="POST" action="contact.php">
        <div class="form-row">
          <div class="form-group">
            <label for="name">Full Name <span class="req">*</span></label>
            <input type="text" id="name" name="name" placeholder="Your name" required />
          </div>

          <div class="form-group">
            <label for="phone">Phone Number <span class="req">*</span></label>
            <input type="tel" id="phone" name="phone" placeholder="e.g. 082 123 4567" required />
          </div>
        </div>

        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" placeholder="your@email.com" />
        </div>

        <div class="form-group">
          <label for="message">Message <span class="req">*</span></label>
          <textarea id="message" name="message" rows="5" placeholder="Tell us how we can help..." required></textarea>
        </div>

        <button type="submit" class="btn btn--primary btn--full">Send Message ⚡</button>
      </form>
    </div>

  </div>
</section>

<?php include 'includes/footer.php'; ?>