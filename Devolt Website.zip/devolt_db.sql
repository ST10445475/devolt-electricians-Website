-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2026 at 05:58 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `devolt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `client_email` varchar(150) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `service` varchar(100) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time NOT NULL,
  `address` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(30) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `client_email`, `full_name`, `phone`, `service`, `booking_date`, `booking_time`, `address`, `notes`, `status`, `created_at`) VALUES
(1, 'olwethuthando323@gmail.com', 'Olwethu', '0630982419', 'Fault Finding & Repairs', '2026-06-23', '08:29:00', 'olwethuthando323@gmail.com', 'jhh', 'Pending', '2026-06-22 15:25:36'),
(2, 'olwethuthando323@gmail.com', 'Olwethu', '0630982419', 'Fault Finding & Repairs', '2026-06-23', '08:29:00', 'olwethuthando323@gmail.com', 'jhh', 'Pending', '2026-06-22 15:29:20'),
(3, 'Alex@gmail.com', 'Alex', '0630982419', 'Backup Power Solution', '2026-06-24', '10:50:00', 'Alex@gmail.com', 'ghhg', 'Pending', '2026-06-22 15:45:24'),
(4, 'katleho@gmail.com', 'Katleho', '0817245348', 'Backup Power Solution', '2026-06-24', '10:00:00', 'katleho@gmail.com', 'dff', 'Pending', '2026-06-22 15:54:50');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `full_name`, `email`, `password`, `created_at`) VALUES
(1, 'Olwethu', 'olwethuthando323@gmail.com', '$2y$10$m34NmvFd6j7w3sMfIqQzzOQ8aThkUKipho87iR88oBvhEsNExGd/C', '2026-06-22 15:07:46'),
(2, 'Tshepiso', 'tshepisoM@gmail.com', '$2y$10$SF59odoKIaAVUw/dYnrWGufYBFNkLbzZsWQOZlGMSy/yzQHcn.1Iu', '2026-06-22 15:42:43'),
(3, 'Alex', 'Alex@gmail.com', '$2y$10$tF0C3U9WNL2/aJegYU.oxeXNSswzh3r2p4MXeSfM2iBpM4/zMLSgi', '2026-06-22 15:44:06'),
(4, 'John', 'johnS@gmail.com', '$2y$10$JeK2VgfUgB/FtphgxADKYeE/HB0iFvq3ypHWiTSUrF9p/TJ1tCImi', '2026-06-22 15:51:32'),
(5, 'Katleho', 'katleho@gmail.com', '$2y$10$wfP1.xnb0eZEA848mrFeF.6d8sRPsfwcYs9poQ6wLoADmNSoSsMvK', '2026-06-22 15:53:28');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `phone`, `email`, `message`, `created_at`) VALUES
(1, 'Olwethu', '0630982419', 'olwethuthando323@gmail.com', 'testing', '2026-06-22 15:09:15'),
(2, 'Olwethu', '0630982419', 'olwethuthando323@gmail.com', 'testing', '2026-06-22 15:12:45');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quote_requests`
--

CREATE TABLE `quote_requests` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `client_type` varchar(50) DEFAULT NULL,
  `service` varchar(100) NOT NULL,
  `location` varchar(150) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `client_email` varchar(150) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'Pending',
  `job_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quote_requests`
--

INSERT INTO `quote_requests` (`id`, `name`, `phone`, `email`, `client_type`, `service`, `location`, `details`, `created_at`, `client_email`, `status`, `job_image`) VALUES
(1, 'Olwethu', '0630982419', 'olwethuthando323@gmail.com', 'Residential', 'DB Board Upgrade', 'Pretoria Central', 'hjhhhd', '2026-06-22 15:04:07', NULL, 'Pending', NULL),
(2, 'Alex', '0630982419', 'Alex@gmail.com', 'Residential', 'Electrical Installation', 'Pretoria Central', 'dff', '2026-06-22 15:46:24', 'Alex@gmail.com', 'Pending', ''),
(3, 'Alex', '0630982419', 'Alex@gmail.com', 'Residential', 'Electrical Installation', 'Pretoria Central', 'dff', '2026-06-22 15:50:32', 'Alex@gmail.com', 'Pending', ''),
(4, 'Katleho', '0817245348', 'katleho@gmail.com', 'Residential', 'DB Board Upgrade', 'Pretoria Central', 'hyu', '2026-06-22 15:55:43', 'katleho@gmail.com', 'Pending', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quote_requests`
--
ALTER TABLE `quote_requests`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quote_requests`
--
ALTER TABLE `quote_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
